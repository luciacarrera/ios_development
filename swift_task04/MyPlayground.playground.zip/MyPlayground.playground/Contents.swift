// CS275
// Lucia Carrera
// Swift Assignment #4
import UIKit

/* EXAMPLE FUNCTION */
// function that will take an array of integers and return an array of just the positive integers from the original array
func positivesOnly(_ intArr: [Int]) -> [Int] {
    let r = intArr.filter { $0 > 0 }
    return r
}

/* FUNCTION #1 */
// converts all characters in all strings in the input array to lower case
func toLower(_ stringArr: [String]) -> [String] {
    let s = stringArr.map({i in i.lowercased()})
    return s
}

/* FUNCTION #2 */
// add together each of the strings in the input array that can be converted // to an integer and return the sum
// use map(_:) and reduce(_:_:)
func addInts(_ stringArr: [String]) -> Int {
    let s = stringArr.map({ Int(i) in let bool = Int(i)}}) //mal
    let rtnval = s.reduce(0, { i, j in
        if i != nil & j != nil { i, j in i + j}
    } )// fill this in with a single statement using reduce(_:_:)
    return rtnval
}



/* FUNCTION #3
// add the absolute values of the entries in intArr and return the sum
func addMagnitudes(_ intArr: [Int]) -> Int {
    let s = // fill this in with a single statement using map(_:)
    let rtnval = // fill this in with a single statement using reduce(_:_:)
    return rtnval
}

/* FUNCTION #4 */
// add together the positive values from the input array and return the sum
func addPositives(_ intArr: [Int]) -> Int {

    let s = // fill this in with a single statement using filter(_:)
    let rtnval = // fill this in with a single statement using reduce(_:_:)
    return rtnval
}
/* FUNCTION #5 */
/* FUNCTION #6 */
/* FUNCTION #7 */
/* FUNCTION # */*/


/* TESTING FUNCTIONS */
// testing example function
let ints = [5, -9, 0, 23, 2, -7, 5, -1]
print("positives are: \(positivesOnly(ints))")

// testing for function #1
let s1 = ["Now", "is", "THE", "tImE"]
print(toLower(s1))
["now", "is", "the", "time"]

// testing for function #2
let s2 = ["0", "one", "2", "three", "4ff", "5", "six", "Seven", "8", "0"]
print(addInts(s2))

/*testing for function #3
let s3 = [0, 1, -1, 2, -2, 3, -3, 4, -4]
print(addMagnitudes(s3))

// testing for function #4
let s4 = [0, 1, -1, 2, -2, 3, -3, 4, -4]
print(addPositives(s4))

*/
